# 物品与功法命名约定

本次检查本体与已安装官方 DLC 的固定目录、归墟宝物、十一界经济成品、傀儡部件、符箓及神机命名入口。保留已有成形的器名和药名，调整境界拼接、功能直译、重复套词与不通顺的名称。

## 命名规则

- 功法以道途、修持意象和传承文体命名，不用当前适用境界代替书名。秘术效果写入说明，名称不直白罗列夺舍、寄生或使用次数。
- 法宝、装备保留可辨认的器形，如剑、甲、鼎、舟；灵材结合材质、来源和意象。丹药不强行嵌入元婴、化神、大乘等使用门槛。筑基丹、洗髓丹等已成形的常用药名保留。
- 同一植物及种子采用一致名称。品阶、境界限制、用途与数值仍由独立字段、标签和说明表达。
- 同系列按既有字数、器形和构词规律命名；须对照相邻品阶及同类条目检查，不能只删除境界词而留下突兀短名。玩家明确设定的趣味命名保留，「英姿神武口服液」属于这一设定。
- 批量商品按各界工艺传统命名，品阶置于括号中；同系不同品阶不必伪造完全不同的药名。傀儡使用阵枢、灵枢、蕴光晶、凝元髓等部件名。
- 内部物品与功法标识随实际名称调整，不再以已经失真的境界标签代指内容。境界枚举、突破范围、品阶字段、事件阶段和测试场景中的真实境界名称保留。

## 兼容与代码边界

上一轮登记更名 1681 项：物品 1569 项、功法 112 部。其中 43 个旧标识有明确的新标识；权威定义、剧情奖励、市场、开局、测试及相关生成工具同步引用。下表同步收录后续命名修订及恢复的原设定。

- [标识兼容表](../cultivation_life/content_identifiers.py)仅处理结构 10 内的内容引用。读档时按明确字段／精确字典键归一，不执行旧结构升级，不扫描或改写用户存档文件，不新增持久字段或年度钩子。
- 背包、功法槽、传承玉简、宿身／本魂快照、NPC 传承、突破辅药、拍卖寄售、商队货批及市场库存共用同一别名表。旧界面提交的引用在请求边界归一，仍执行原业务校验。
- 采购委托的 `definition_id`、材料奖励的 `reward_definition_id` 和 NPC 的 `combat_artifact_id` 同样属于内容引用，读档及旧页面提交共用精确别名处理；不以改名取消既有订单，也不丢失原主战器物。
- 同一映射字典同时出现新旧键时明确拒绝，不覆盖物资或账目。未知内容、自定义法宝名称、人物姓名、历史叙述与玩家文本不作文字替换。
- 已得固定物品与已学功法显示权威目录的新名称；旧市场／拍卖列表仅更新显示，不刷新抽取、不修改报价和成交状态。神机旧档及自定法宝保留既有名称与冻结属性。
- 数值、配方投入、来源、品阶、境界条件、DLC 资格、夺舍次数与权威结算入口均不改变；没有增加移动或跨界例外。

## 固定目录更名表

批量经济商品和傀儡部件见[商品目录](economy-supply-catalog.md)及对应生成模块；下表记录固定目录的名称或标识变化。

| 原名称 | 新名称 | 当前标识 |
|---|---|---|
| 天魔炼虚录 | 天魔游玄录 | `TECH_HEAVEN_DEMON_MYSTERIES` |
| 混元抱丹书 | 抱朴玄经 | `TECH_BAOPU_CANON` |
| 大罗玄经 | 玄都真解 | `TECH_XUANDU_CANON` |
| 婴神太虚录 | 黄庭内景经 | `TECH_YELLOW_COURT_INNER` |
| 化神观天卷 | 玄览天机卷 | `TECH_MYSTIC_OBSERVATION` |
| 虚界炼元篇 | 虚界炼元篇 | `TECH_VOID_ORIGIN_CANON` |
| 万法归一典 | 万法归一典 | `TECH_MYRIAD_LAW_UNITY` |
| 大乘渡世经 | 太上济世经 | `TECH_SUPREME_SALVATION` |
| 空明炼虚典 | 空明洞微典 | `TECH_LUCID_SUBTLETY_CANON` |
| 真仙引灵经 | 餐霞承露经 | `TECH_ROSY_CLOUD_BREATH` |
| 妖丹烘炉法 | 赤炉养元篇 | `TECH_CRIMSON_FURNACE` |
| 搬山大力妖身 | 担岳真形篇 | `TECH_MOUNTAIN_BEARING_BODY` |
| 无底阴身篇 | 九泉藏形篇 | `TECH_GUIXU_YELLOW_SPRING_03` |
| 生死簿遁法 | 冥关无迹法 | `TECH_GUIXU_YELLOW_SPRING_07` |
| 祖灵归潮经 | 荒原纳息经 | `TECH_GUIXU_MONSTER_REALM_01` |
| 祖灵定界录 | 群山载灵录 | `TECH_GUIXU_MONSTER_REALM_02` |
| 祖灵炼身篇 | 百骸鸣岳篇 | `TECH_GUIXU_MONSTER_REALM_03` |
| 祖灵照神法 | 烛野观神法 | `TECH_GUIXU_MONSTER_REALM_04` |
| 祖灵渡厄诀 | 苍虬蜕鳞诀 | `TECH_GUIXU_MONSTER_REALM_05` |
| 祖灵不灭典 | 万木同春典 | `TECH_GUIXU_MONSTER_REALM_06` |
| 祖灵隐虚术 | 伏草藏真术 | `TECH_GUIXU_MONSTER_REALM_07` |
| 祖灵遁空篇 | 乘飙御云篇 | `TECH_GUIXU_MONSTER_REALM_08` |
| 祖灵溯源经 | 祖庭归藏经 | `TECH_GUIXU_MONSTER_REALM_09` |
| 祖灵太初书 | 太古山海书 | `TECH_GUIXU_MONSTER_REALM_10` |
| 天律归潮经 | 云笈归真经 | `TECH_GUIXU_CELESTIAL_01` |
| 天律定界录 | 天衡定序录 | `TECH_GUIXU_CELESTIAL_02` |
| 天律炼身篇 | 金阙炼形篇 | `TECH_GUIXU_CELESTIAL_03` |
| 天律照神法 | 玉宸照微法 | `TECH_GUIXU_CELESTIAL_04` |
| 天律渡厄诀 | 星槎济厄诀 | `TECH_GUIXU_CELESTIAL_05` |
| 天律不灭典 | 清都长生典 | `TECH_GUIXU_CELESTIAL_06` |
| 天律隐虚术 | 烟霞敛迹术 | `TECH_GUIXU_CELESTIAL_07` |
| 天律遁空篇 | 蹑景乘虚篇 | `TECH_GUIXU_CELESTIAL_08` |
| 天律溯源经 | 河图溯道经 | `TECH_GUIXU_CELESTIAL_09` |
| 天律太初书 | 先天无极书 | `TECH_GUIXU_CELESTIAL_10` |
| 劫刃归潮经 | 烬海纳煞经 | `TECH_GUIXU_ASURA_01` |
| 劫刃定界录 | 铁狱镇疆录 | `TECH_GUIXU_ASURA_02` |
| 劫刃炼身篇 | 赤铜铸骨篇 | `TECH_GUIXU_ASURA_03` |
| 劫刃照神法 | 血月窥心法 | `TECH_GUIXU_ASURA_04` |
| 劫刃渡厄诀 | 断劫无回诀 | `TECH_GUIXU_ASURA_05` |
| 劫刃不灭典 | 修罗百战典 | `TECH_GUIXU_ASURA_06` |
| 劫刃隐虚术 | 暗尘匿锋术 | `TECH_GUIXU_ASURA_07` |
| 劫刃遁空篇 | 掠火逐日篇 | `TECH_GUIXU_ASURA_08` |
| 劫刃溯源经 | 兵主归藏经 | `TECH_GUIXU_ASURA_09` |
| 劫刃太初书 | 无间玄枢书 | `TECH_GUIXU_ASURA_10` |
| 龙源归潮经 | 苍溟吐息经 | `TECH_GUIXU_NETHER_01` |
| 龙源定界录 | 龙庭镇域录 | `TECH_GUIXU_NETHER_02` |
| 龙源炼身篇 | 玄鳞铸身篇 | `TECH_GUIXU_NETHER_03` |
| 龙源照神法 | 渊龙照夜法 | `TECH_GUIXU_NETHER_04` |
| 龙源渡厄诀 | 游渊御厄诀 | `TECH_GUIXU_NETHER_05` |
| 龙源不灭典 | 蟠天长生典 | `TECH_GUIXU_NETHER_06` |
| 龙源隐虚术 | 蜃影藏真术 | `TECH_GUIXU_NETHER_07` |
| 龙源遁空篇 | 御霆巡天篇 | `TECH_GUIXU_NETHER_08` |
| 龙源溯源经 | 九渊归祖经 | `TECH_GUIXU_NETHER_09` |
| 龙源太初书 | 烛龙开曜书 | `TECH_GUIXU_NETHER_10` |
| 溯魂归潮经 | 忘川归寂经 | `TECH_GUIXU_REINCARNATION_01` |
| 溯魂定界录 | 冥衡定业录 | `TECH_GUIXU_REINCARNATION_02` |
| 溯魂炼身篇 | 幽莲塑魄篇 | `TECH_GUIXU_REINCARNATION_03` |
| 溯魂照神法 | 三生返照法 | `TECH_GUIXU_REINCARNATION_04` |
| 溯魂渡厄诀 | 彼岸渡厄诀 | `TECH_GUIXU_REINCARNATION_05` |
| 溯魂不灭典 | 长夜长明典 | `TECH_GUIXU_REINCARNATION_06` |
| 溯魂隐虚术 | 残梦匿魂术 | `TECH_GUIXU_REINCARNATION_07` |
| 溯魂遁空篇 | 履影渡川篇 | `TECH_GUIXU_REINCARNATION_08` |
| 溯魂溯源经 | 宿世归藏经 | `TECH_GUIXU_REINCARNATION_09` |
| 溯魂太初书 | 无始玄冥书 | `TECH_GUIXU_REINCARNATION_10` |
| 血海归元魔典 | 血海玄枢经 | `TECH_ASURA_9_MAIN` |
| 血海破军戮神诀 | 赤锋裂阵诀 | `TECH_ASURA_9_COMBAT` |
| 血海不灭战躯经 | 铜骨烬身经 | `TECH_ASURA_9_BODY` |
| 血海照狱观心法 | 照狱明心法 | `TECH_ASURA_9_SENSE` |
| 无间归元魔典 | 无间藏元典 | `TECH_ASURA_10_MAIN` |
| 无间破军戮神诀 | 断岳摧城录 | `TECH_ASURA_10_COMBAT` |
| 无间不灭战躯经 | 铁狱金身篇 | `TECH_ASURA_10_BODY` |
| 无间照狱观心法 | 寒灯烛念法 | `TECH_ASURA_10_SENSE` |
| 焚天归元魔典 | 焚天炼日经 | `TECH_ASURA_11_MAIN` |
| 焚天破军戮神诀 | 烬海戮星诀 | `TECH_ASURA_11_COMBAT` |
| 焚天不灭战躯经 | 赤霄百劫躯 | `TECH_ASURA_11_BODY` |
| 焚天照狱观心法 | 寂照窥玄录 | `TECH_ASURA_11_SENSE` |
| 寂灭归元魔典 | 寂灭归藏典 | `TECH_ASURA_12_MAIN` |
| 寂灭破军戮神诀 | 无回断劫书 | `TECH_ASURA_12_COMBAT` |
| 寂灭不灭战躯经 | 兵主不坏身 | `TECH_ASURA_12_BODY` |
| 寂灭照狱观心法 | 玄冥独照经 | `TECH_ASURA_12_SENSE` |
| 太荒纳元真经 | 太荒吐息经 | `TECH_NETHER_9_MAIN` |
| 太荒裂穹战诀 | 龙爪裂穹诀 | `TECH_NETHER_9_COMBAT` |
| 太荒镇岳锻骨经 | 玄鳞镇岳经 | `TECH_NETHER_9_BODY` |
| 太荒万象观神法 | 烛夜观神法 | `TECH_NETHER_9_SENSE` |
| 万灵纳元真经 | 万灵朝元典 | `TECH_NETHER_10_MAIN` |
| 万灵裂穹战诀 | 沧溟掣浪录 | `TECH_NETHER_10_COMBAT` |
| 万灵镇岳锻骨经 | 盘岳龙骨篇 | `TECH_NETHER_10_BODY` |
| 万灵万象观神法 | 蜃楼照影法 | `TECH_NETHER_10_SENSE` |
| 混沌纳元真经 | 浑天养真经 | `TECH_NETHER_11_MAIN` |
| 混沌裂穹战诀 | 九渊断界诀 | `TECH_NETHER_11_COMBAT` |
| 混沌镇岳锻骨经 | 蟠天不坏躯 | `TECH_NETHER_11_BODY` |
| 混沌万象观神法 | 玄瞳烛微录 | `TECH_NETHER_11_SENSE` |
| 太初纳元真经 | 太初归藏经 | `TECH_NETHER_12_MAIN` |
| 太初裂穹战诀 | 烛龙开天书 | `TECH_NETHER_12_COMBAT` |
| 太初镇岳锻骨经 | 山海无量身 | `TECH_NETHER_12_BODY` |
| 太初万象观神法 | 万象澄明典 | `TECH_NETHER_12_SENSE` |
| 三生归藏魂经 | 三生归藏经 | `TECH_REINCARNATION_9_MAIN` |
| 三生断业斩魂诀 | 忘川断业诀 | `TECH_REINCARNATION_9_COMBAT` |
| 三生凝魄法身经 | 幽莲凝魄篇 | `TECH_REINCARNATION_9_BODY` |
| 三生照见前尘法 | 前尘返照录 | `TECH_REINCARNATION_9_SENSE` |
| 六道归藏魂经 | 六道玄枢典 | `TECH_REINCARNATION_10_MAIN` |
| 六道断业斩魂诀 | 冥河裁劫书 | `TECH_REINCARNATION_10_COMBAT` |
| 六道凝魄法身经 | 彼岸无漏身 | `TECH_REINCARNATION_10_BODY` |
| 六道照见前尘法 | 宿世明灯法 | `TECH_REINCARNATION_10_SENSE` |
| 无生归藏魂经 | 无生寂照经 | `TECH_REINCARNATION_11_MAIN` |
| 无生断业斩魂诀 | 寒照斩缘诀 | `TECH_REINCARNATION_11_COMBAT` |
| 无生凝魄法身经 | 空华不坏身 | `TECH_REINCARNATION_11_BODY` |
| 无生照见前尘法 | 长夜观心录 | `TECH_REINCARNATION_11_SENSE` |
| 太始归藏魂经 | 太始藏真典 | `TECH_REINCARNATION_12_MAIN` |
| 太始断业斩魂诀 | 无始断轮经 | `TECH_REINCARNATION_12_COMBAT` |
| 太始凝魄法身经 | 大寂琉璃身 | `TECH_REINCARNATION_12_BODY` |
| 太始照见前尘法 | 一念照玄书 | `TECH_REINCARNATION_12_SENSE` |
| 无相夺舍经 | 蝉蜕玄章 | `TECH_CICADA_METAMORPHOSIS` |
| 万相寄生天书 | 梦蝶游世经 | `TECH_BUTTERFLY_DREAM_CANON` |
| 清虚定元丹 | 清虚定元丹 | `clear_void_origin_pill` |
| 九转通脉丹 | 九转通脉丹 | `nine_turn_meridian_pill` |
| 太清破障丹 | 太清破障丹 | `supreme_clarity_barrier_pill` |
| 金华凝道丹 | 金华凝道丹 | `golden_flower_dao_pill` |
| 不朽养真丹 | 不朽养真丹 | `imperishable_truth_pill` |
| 紫霄开玄丹 | 紫霄开玄丹 | `purple_heaven_mystery_pill` |
| 太乙抱一丹 | 太素抱一丹 | `supreme_unity_pill` |
| 三花蕴道丹 | 三花蕴道丹 | `three_flower_dao_pill` |
| 五炁归真丹 | 五炁归真丹 | `five_breath_truth_pill` |
| 大罗无漏丹 | 玄元无漏丹 | `boundless_perfection_pill` |
| 混元合道丹 | 混元合道丹 | `primordial_harmony_pill` |
| 万象通明丹 | 万象通明丹 | `myriad_lucid_pill` |
| 英姿神武口服液 | 英姿神武口服液（保留原设定） | `qilin_blessing_elixir` |
| 婴神香 | 紫府心香 | `purple_mansion_incense` |
| 通天灵宝 | 承天如意 | `heaven_bearing_scepter` |
| 抱婴参 | 九曲灵参 | `nine_curve_ginseng` |
| 归婴丹 | 九还凝真丹 | `nine_return_truth_pill` |
| 炼虚丹 | 洞玄丹 | `profound_mystery_pill` |
| 明心多莲 | 澄心莲 | `clear_mind_lotus` |
| 大乘丹 | 承天丹 | `heaven_bearing_pill` |
| 大乘灵丹 | 玄穹丹 | `mystic_firmament_pill` |
| 天法律液 | 天宪玉液 | `heavenly_law_essence` |
| 婴元果 | 紫蕊玄果 | `purple_stamen_fruit` |
| 婴变丹 | 玉枢丹 | `jade_pivot_pill` |
| 化神玉露 | 玄览玉露 | `mystic_vision_dew` |
| 抱婴参种 | 九曲灵参种 | `nine_curve_herb_seed` |
| 婴火玄晶 | 离照玄晶 | `radiant_flame_crystal` |
| 后土之土 | 后土息壤 | `houtu_clay` |
| 聚婴魂髓 | 幽璇魂髓 | `dark_jade_soul_marrow` |
| 养婴阴露 | 月魄玄露 | `moon_soul_dew` |
| 化神引魂香 | 返照香 | `returning_light_incense` |
| 大乘渡厄香 | 清寂香 | `serene_incense` |
| 大乘镇魂髓 | 九幽凝魄髓 | `nine_depths_soul_marrow` |
| 兽婴丹 | 啸月丹 | `moon_howl_pill` |
| 归孔法环 | 尾闾法环 | `guixu_weir_equipment_10` |
| 万流归孔阵盘 | 万流归渊阵盘 | `guixu_weir_consumable_05` |
| 归孔法则藤 | 归渊玄藤 | `guixu_weir_plant_09` |
| 混沌卵舟 | 鲲胎云舟 | `guixu_beast_vortex_equipment_09` |
| 无底阴芝 | 九泉阴芝 | `guixu_yellow_spring_plant_03` |
| 生死簿藤 | 玄牒藤 | `guixu_yellow_spring_plant_07` |
| 生死簿银 | 冥契银 | `guixu_yellow_spring_material_07` |
| 祖灵镇海珠 | 苍山镇海珠 | `guixu_monster_realm_equipment_01` |
| 祖灵归潮旗 | 万木招灵旗 | `guixu_monster_realm_equipment_02` |
| 祖灵裂界剑 | 獠月裂界剑 | `guixu_monster_realm_equipment_03` |
| 祖灵定天甲 | 玄兕负天甲 | `guixu_monster_realm_equipment_04` |
| 祖灵照魂鼎 | 百兽照魂鼎 | `guixu_monster_realm_equipment_05` |
| 祖灵渡劫轮 | 回山渡劫轮 | `guixu_monster_realm_equipment_06` |
| 祖灵天心镜 | 灵犀照心镜 | `guixu_monster_realm_equipment_07` |
| 祖灵流光舟 | 青鸾流光舟 | `guixu_monster_realm_equipment_08` |
| 祖灵界尺 | 量天骨尺 | `guixu_monster_realm_equipment_09` |
| 祖灵镇源碑 | 祖庭镇源碑 | `guixu_monster_realm_equipment_10` |
| 祖灵无相钟 | 空山无相钟 | `guixu_monster_realm_equipment_11` |
| 祖灵太初印 | 洪荒初文印 | `guixu_monster_realm_equipment_12` |
| 祖灵还元丹 | 青岚还元丹 | `guixu_monster_realm_consumable_01` |
| 祖灵定魂露 | 鹿鸣定魂露 | `guixu_monster_realm_consumable_02` |
| 祖灵续命丸 | 松龄续命丸 | `guixu_monster_realm_consumable_03` |
| 祖灵洗脉丹 | 碧涧洗脉丹 | `guixu_monster_realm_consumable_04` |
| 祖灵回天散 | 回阳百草散 | `guixu_monster_realm_consumable_05` |
| 祖灵养神液 | 月华养神液 | `guixu_monster_realm_consumable_06` |
| 祖灵生肌膏 | 玉脂生肌膏 | `guixu_monster_realm_consumable_07` |
| 祖灵渡厄丹 | 古木渡厄丹 | `guixu_monster_realm_consumable_08` |
| 祖灵九叶莲 | 碧潭九叶莲 | `guixu_monster_realm_plant_01` |
| 祖灵灵芝 | 鹿角灵芝 | `guixu_monster_realm_plant_02` |
| 祖灵玉参 | 雪岭玉参 | `guixu_monster_realm_plant_03` |
| 祖灵长生藤 | 盘山长生藤 | `guixu_monster_realm_plant_04` |
| 祖灵归元草 | 晨露归元草 | `guixu_monster_realm_plant_05` |
| 祖灵照神花 | 灵犀照神花 | `guixu_monster_realm_plant_06` |
| 祖灵太初果 | 洪荒初阳果 | `guixu_monster_realm_plant_07` |
| 祖灵镇魂苔 | 青丘镇魂苔 | `guixu_monster_realm_plant_08` |
| 祖灵天葵 | 朝露天葵 | `guixu_monster_realm_plant_09` |
| 祖灵万年桑 | 万年青桑 | `guixu_monster_realm_plant_10` |
| 祖灵母金 | 苍山母金 | `guixu_monster_realm_material_01` |
| 祖灵源晶 | 祖庭玄晶 | `guixu_monster_realm_material_02` |
| 祖灵法砂 | 山海法砂 | `guixu_monster_realm_material_03` |
| 祖灵玄钢 | 兽纹玄钢 | `guixu_monster_realm_material_04` |
| 祖灵界石 | 荒原界石 | `guixu_monster_realm_material_05` |
| 祖灵玉髓 | 地脉玉髓 | `guixu_monster_realm_material_06` |
| 祖灵神铜 | 青犀神铜 | `guixu_monster_realm_material_07` |
| 祖灵天银 | 月魄天银 | `guixu_monster_realm_material_08` |
| 祖灵灵玉 | 鹿鸣灵玉 | `guixu_monster_realm_material_09` |
| 祖灵太初核 | 祖庭混元核 | `guixu_monster_realm_material_10` |
| 天律镇海珠 | 玉宸镇海珠 | `guixu_celestial_equipment_01` |
| 天律归潮旗 | 云笈归潮旗 | `guixu_celestial_equipment_02` |
| 天律裂界剑 | 天衡裂界剑 | `guixu_celestial_equipment_03` |
| 天律定天甲 | 金阙定天甲 | `guixu_celestial_equipment_04` |
| 天律照魂鼎 | 紫微照魂鼎 | `guixu_celestial_equipment_05` |
| 天律渡劫轮 | 星槎渡劫轮 | `guixu_celestial_equipment_06` |
| 天律天心镜 | 太清天心镜 | `guixu_celestial_equipment_07` |
| 天律流光舟 | 蹑景流光舟 | `guixu_celestial_equipment_08` |
| 天律界尺 | 河洛界尺 | `guixu_celestial_equipment_09` |
| 天律镇源碑 | 玄都镇源碑 | `guixu_celestial_equipment_10` |
| 天律无相钟 | 清都无相钟 | `guixu_celestial_equipment_11` |
| 天律太初印 | 先天河图印 | `guixu_celestial_equipment_12` |
| 天律还元丹 | 餐霞还元丹 | `guixu_celestial_consumable_01` |
| 天律定魂露 | 玉清定魂露 | `guixu_celestial_consumable_02` |
| 天律续命丸 | 丹霞续命丸 | `guixu_celestial_consumable_03` |
| 天律洗脉丹 | 琼华洗脉丹 | `guixu_celestial_consumable_04` |
| 天律回天散 | 青霄回天散 | `guixu_celestial_consumable_05` |
| 天律养神液 | 紫宸养神液 | `guixu_celestial_consumable_06` |
| 天律生肌膏 | 云母生肌膏 | `guixu_celestial_consumable_07` |
| 天律渡厄丹 | 玄都渡厄丹 | `guixu_celestial_consumable_08` |
| 天律九叶莲 | 瑶池九叶莲 | `guixu_celestial_plant_01` |
| 天律灵芝 | 紫盖灵芝 | `guixu_celestial_plant_02` |
| 天律玉参 | 玉京雪参 | `guixu_celestial_plant_03` |
| 天律长生藤 | 云台长生藤 | `guixu_celestial_plant_04` |
| 天律归元草 | 清露归元草 | `guixu_celestial_plant_05` |
| 天律照神花 | 丹阙照神花 | `guixu_celestial_plant_06` |
| 天律太初果 | 先天玄阳果 | `guixu_celestial_plant_07` |
| 天律镇魂苔 | 太清镇魂苔 | `guixu_celestial_plant_08` |
| 天律天葵 | 朝阳天葵 | `guixu_celestial_plant_09` |
| 天律万年桑 | 万年扶桑 | `guixu_celestial_plant_10` |
| 天律母金 | 金阙母金 | `guixu_celestial_material_01` |
| 天律源晶 | 玉京玄晶 | `guixu_celestial_material_02` |
| 天律法砂 | 河图法砂 | `guixu_celestial_material_03` |
| 天律玄钢 | 天衡玄钢 | `guixu_celestial_material_04` |
| 天律界石 | 云台界石 | `guixu_celestial_material_05` |
| 天律玉髓 | 琼华玉髓 | `guixu_celestial_material_06` |
| 天律神铜 | 丹霞神铜 | `guixu_celestial_material_07` |
| 天律天银 | 星河天银 | `guixu_celestial_material_08` |
| 天律灵玉 | 紫宸灵玉 | `guixu_celestial_material_09` |
| 天律太初核 | 先天混元核 | `guixu_celestial_material_10` |
| 劫刃镇海珠 | 烬海镇潮珠 | `guixu_asura_equipment_01` |
| 劫刃归潮旗 | 血月归潮旗 | `guixu_asura_equipment_02` |
| 劫刃裂界剑 | 无回裂界剑 | `guixu_asura_equipment_03` |
| 劫刃定天甲 | 铜狱定天甲 | `guixu_asura_equipment_04` |
| 劫刃照魂鼎 | 寒灯照魂鼎 | `guixu_asura_equipment_05` |
| 劫刃渡劫轮 | 断劫无回轮 | `guixu_asura_equipment_06` |
| 劫刃天心镜 | 赤瞳天心镜 | `guixu_asura_equipment_07` |
| 劫刃流光舟 | 掠火流光舟 | `guixu_asura_equipment_08` |
| 劫刃界尺 | 裁疆铁尺 | `guixu_asura_equipment_09` |
| 劫刃镇源碑 | 兵主镇源碑 | `guixu_asura_equipment_10` |
| 劫刃无相钟 | 寂照无相钟 | `guixu_asura_equipment_11` |
| 劫刃太初印 | 无间玄枢印 | `guixu_asura_equipment_12` |
| 劫刃还元丹 | 赤霞还元丹 | `guixu_asura_consumable_01` |
| 劫刃定魂露 | 寒灯定魂露 | `guixu_asura_consumable_02` |
| 劫刃续命丸 | 余烬续命丸 | `guixu_asura_consumable_03` |
| 劫刃洗脉丹 | 血泉洗脉丹 | `guixu_asura_consumable_04` |
| 劫刃回天散 | 烬海回天散 | `guixu_asura_consumable_05` |
| 劫刃养神液 | 夜火养神液 | `guixu_asura_consumable_06` |
| 劫刃生肌膏 | 赤铜生肌膏 | `guixu_asura_consumable_07` |
| 劫刃渡厄丹 | 止戈渡厄丹 | `guixu_asura_consumable_08` |
| 劫刃九叶莲 | 血池九叶莲 | `guixu_asura_plant_01` |
| 劫刃灵芝 | 赤盖灵芝 | `guixu_asura_plant_02` |
| 劫刃玉参 | 烬原玉参 | `guixu_asura_plant_03` |
| 劫刃长生藤 | 铁壁长生藤 | `guixu_asura_plant_04` |
| 劫刃归元草 | 断刃归元草 | `guixu_asura_plant_05` |
| 劫刃照神花 | 夜火照神花 | `guixu_asura_plant_06` |
| 劫刃太初果 | 兵主玄阳果 | `guixu_asura_plant_07` |
| 劫刃镇魂苔 | 铜狱镇魂苔 | `guixu_asura_plant_08` |
| 劫刃天葵 | 烈阳天葵 | `guixu_asura_plant_09` |
| 劫刃万年桑 | 万年赤桑 | `guixu_asura_plant_10` |
| 劫刃母金 | 兵主母金 | `guixu_asura_material_01` |
| 劫刃源晶 | 血月玄晶 | `guixu_asura_material_02` |
| 劫刃法砂 | 断劫法砂 | `guixu_asura_material_03` |
| 劫刃玄钢 | 铁狱玄钢 | `guixu_asura_material_04` |
| 劫刃界石 | 烬原界石 | `guixu_asura_material_05` |
| 劫刃玉髓 | 赤霞玉髓 | `guixu_asura_material_06` |
| 劫刃神铜 | 血纹神铜 | `guixu_asura_material_07` |
| 劫刃天银 | 冷月天银 | `guixu_asura_material_08` |
| 劫刃灵玉 | 寒灯灵玉 | `guixu_asura_material_09` |
| 劫刃太初核 | 无间混元核 | `guixu_asura_material_10` |
| 龙源镇海珠 | 沧溟镇海珠 | `guixu_nether_equipment_01` |
| 龙源归潮旗 | 御霆归潮旗 | `guixu_nether_equipment_02` |
| 龙源裂界剑 | 龙牙裂界剑 | `guixu_nether_equipment_03` |
| 龙源定天甲 | 玄鳞定天甲 | `guixu_nether_equipment_04` |
| 龙源照魂鼎 | 烛夜照魂鼎 | `guixu_nether_equipment_05` |
| 龙源渡劫轮 | 游渊渡劫轮 | `guixu_nether_equipment_06` |
| 龙源天心镜 | 明渊天心镜 | `guixu_nether_equipment_07` |
| 龙源流光舟 | 蜃影流光舟 | `guixu_nether_equipment_08` |
| 龙源界尺 | 盘天龙尺 | `guixu_nether_equipment_09` |
| 龙源镇源碑 | 九渊镇源碑 | `guixu_nether_equipment_10` |
| 龙源无相钟 | 潜龙无相钟 | `guixu_nether_equipment_11` |
| 龙源太初印 | 烛龙初曜印 | `guixu_nether_equipment_12` |
| 龙源还元丹 | 龙涎还元丹 | `guixu_nether_consumable_01` |
| 龙源定魂露 | 明渊定魂露 | `guixu_nether_consumable_02` |
| 龙源续命丸 | 玄鳞续命丸 | `guixu_nether_consumable_03` |
| 龙源洗脉丹 | 渊泉洗脉丹 | `guixu_nether_consumable_04` |
| 龙源回天散 | 沧溟回天散 | `guixu_nether_consumable_05` |
| 龙源养神液 | 烛夜养神液 | `guixu_nether_consumable_06` |
| 龙源生肌膏 | 龙脂生肌膏 | `guixu_nether_consumable_07` |
| 龙源渡厄丹 | 御霆渡厄丹 | `guixu_nether_consumable_08` |
| 龙源九叶莲 | 渊池九叶莲 | `guixu_nether_plant_01` |
| 龙源灵芝 | 龙角灵芝 | `guixu_nether_plant_02` |
| 龙源玉参 | 沧溟玉参 | `guixu_nether_plant_03` |
| 龙源长生藤 | 蟠天长生藤 | `guixu_nether_plant_04` |
| 龙源归元草 | 蜃露归元草 | `guixu_nether_plant_05` |
| 龙源照神花 | 烛夜照神花 | `guixu_nether_plant_06` |
| 龙源太初果 | 龙庭玄阳果 | `guixu_nether_plant_07` |
| 龙源镇魂苔 | 深渊镇魂苔 | `guixu_nether_plant_08` |
| 龙源天葵 | 明曜天葵 | `guixu_nether_plant_09` |
| 龙源万年桑 | 万年龙桑 | `guixu_nether_plant_10` |
| 龙源母金 | 龙庭母金 | `guixu_nether_material_01` |
| 龙源源晶 | 九渊玄晶 | `guixu_nether_material_02` |
| 龙源法砂 | 烛龙法砂 | `guixu_nether_material_03` |
| 龙源玄钢 | 鳞纹玄钢 | `guixu_nether_material_04` |
| 龙源界石 | 蜃海界石 | `guixu_nether_material_05` |
| 龙源玉髓 | 苍溟玉髓 | `guixu_nether_material_06` |
| 龙源神铜 | 盘龙神铜 | `guixu_nether_material_07` |
| 龙源天银 | 烛夜天银 | `guixu_nether_material_08` |
| 龙源灵玉 | 明渊灵玉 | `guixu_nether_material_09` |
| 龙源太初核 | 龙庭混元核 | `guixu_nether_material_10` |
| 溯魂镇海珠 | 忘川镇海珠 | `guixu_reincarnation_equipment_01` |
| 溯魂归潮旗 | 残梦归潮旗 | `guixu_reincarnation_equipment_02` |
| 溯魂裂界剑 | 断缘裂界剑 | `guixu_reincarnation_equipment_03` |
| 溯魂定天甲 | 幽莲定天甲 | `guixu_reincarnation_equipment_04` |
| 溯魂照魂鼎 | 宿世照魂鼎 | `guixu_reincarnation_equipment_05` |
| 溯魂渡劫轮 | 彼岸渡劫轮 | `guixu_reincarnation_equipment_06` |
| 溯魂天心镜 | 返照天心镜 | `guixu_reincarnation_equipment_07` |
| 溯魂流光舟 | 渡影流光舟 | `guixu_reincarnation_equipment_08` |
| 溯魂界尺 | 冥衡界尺 | `guixu_reincarnation_equipment_09` |
| 溯魂镇源碑 | 无始镇源碑 | `guixu_reincarnation_equipment_10` |
| 溯魂无相钟 | 长夜无相钟 | `guixu_reincarnation_equipment_11` |
| 溯魂太初印 | 三生玄牒印 | `guixu_reincarnation_equipment_12` |
| 溯魂还元丹 | 长明还元丹 | `guixu_reincarnation_consumable_01` |
| 溯魂定魂露 | 宿世定魂露 | `guixu_reincarnation_consumable_02` |
| 溯魂续命丸 | 彼岸续命丸 | `guixu_reincarnation_consumable_03` |
| 溯魂洗脉丹 | 忘川洗脉丹 | `guixu_reincarnation_consumable_04` |
| 溯魂回天散 | 幽莲回天散 | `guixu_reincarnation_consumable_05` |
| 溯魂养神液 | 残梦养神液 | `guixu_reincarnation_consumable_06` |
| 溯魂生肌膏 | 月魄生肌膏 | `guixu_reincarnation_consumable_07` |
| 溯魂渡厄丹 | 无生渡厄丹 | `guixu_reincarnation_consumable_08` |
| 溯魂九叶莲 | 彼岸九叶莲 | `guixu_reincarnation_plant_01` |
| 溯魂灵芝 | 幽盖灵芝 | `guixu_reincarnation_plant_02` |
| 溯魂玉参 | 月魄玉参 | `guixu_reincarnation_plant_03` |
| 溯魂长生藤 | 三生长生藤 | `guixu_reincarnation_plant_04` |
| 溯魂归元草 | 残梦归元草 | `guixu_reincarnation_plant_05` |
| 溯魂照神花 | 返照幽昙花 | `guixu_reincarnation_plant_06` |
| 溯魂太初果 | 宿世玄阳果 | `guixu_reincarnation_plant_07` |
| 溯魂镇魂苔 | 长夜镇魂苔 | `guixu_reincarnation_plant_08` |
| 溯魂天葵 | 幽光天葵 | `guixu_reincarnation_plant_09` |
| 溯魂万年桑 | 万年冥桑 | `guixu_reincarnation_plant_10` |
| 溯魂母金 | 冥衡母金 | `guixu_reincarnation_material_01` |
| 溯魂源晶 | 宿世玄晶 | `guixu_reincarnation_material_02` |
| 溯魂法砂 | 三生法砂 | `guixu_reincarnation_material_03` |
| 溯魂玄钢 | 幽纹玄钢 | `guixu_reincarnation_material_04` |
| 溯魂界石 | 彼岸界石 | `guixu_reincarnation_material_05` |
| 溯魂玉髓 | 月魄玉髓 | `guixu_reincarnation_material_06` |
| 溯魂神铜 | 忘川神铜 | `guixu_reincarnation_material_07` |
| 溯魂天银 | 长夜天银 | `guixu_reincarnation_material_08` |
| 溯魂灵玉 | 残梦灵玉 | `guixu_reincarnation_material_09` |
| 溯魂太初核 | 无始混元核 | `guixu_reincarnation_material_10` |
| 太日神光 | 大日神光 | `great_sun_divine_light` |
| 三味真火 | 三昧真火 | `samadhi_true_fire` |

## 验证

本次按领域串行执行 23 个测试文件，共 471 项测试通过，未运行全仓回归。覆盖目录加载、结构 10 旧标识读写、功法等级与玉简、拍卖、经济配方、傀儡、符箓、神机、鬼修、妖修、仙境及跨界引用；新增兼容测试见 [test_content_naming.py](../tests/test_content_naming.py)。完整状态往返比较确认市场实物、寄售和资金记录保持一致，加载不改写测试存档文件。

[名称与旧页面点击验收](../tests/browser_content_naming.py)通过：新名称、特殊效果说明、旧标识升级、玉简消耗、自定器名及开局玉液使用。`tests/browser_events_212.py` 使用低内存模式通过桌面／手机、过期页面恢复、后续奖励、忙碌解除及仍应禁用的选项检查。浏览器逐个关闭后再运行下一组；未启动 Android 模拟器。

跨界状态合同、模块依赖和文档检查均通过。更新前后的权威内容文档按明确标识映射对齐，排除显示名称、说明、标题与正文后差异为零；固定目录与生成目录未发现同名冲突。约 1.25 MB 的状态样本中，单次标识检查中位耗时约 14 ms，未变分支直接复用，没有新增年度扫描。

上述记录为命名修改阶段的验收。后续按用户要求随 v2.14.1 发行，使用 `scripts/verify_scoped_release.py --profile naming` 重新绑定最终源码；增加命名兼容和战争相关的发布专项，以及 Windows EXE 和签名 Android 12 成品验收。最终测试数量、版本和哈希以 `dist/release-2.14.1*.json` 为准，本轮不运行全仓回归。

## v2.14.1 后续源码修订

按用户要求恢复「英姿神武口服液」，保留现有物品编号及其旧编号别名，避免两次改名使已发布版本的引用失效。服用记录和手册同步恢复；仙界十二种破境丹保持五字结构，归墟同类界尺、轮器与照神灵植也按原系列统一。仅六项名称及其说明引用有变化，目录的属性、价格、配方、来源和突破条件保持原值。

复核发现两个兼容遗漏：旧档采购委托引用旧 `definition_id` 会被误判为内容不可用并取消，旧 NPC 的 `combat_artifact_id` 会失去目录解析。现沿用原纯解码别名表处理，保留订单、实际器物、数量、原交付地点及结算入口；不补发物资或重复交付，不新增持久字段、移动规则、年度钩子或用户存档修写。新增回归覆盖真实读档、订单完成、主战法宝投影及 HTTP 旧页面预览／发布／年度交付，特殊开局物品仍不能经委托获取。

命名修订阶段只验证相关领域，串行记录见 `build/naming-revision-validation/report.json` 与 `catalog.json`；浏览器验证恢复后的口服液名称、旧按钮提交和既有事件恢复。随后按用户新增指令随 v2.14.2 的[十一界镶材](natal-materials.md)一并发行，最终源码、成品及验收范围以 `dist/release-2.14.2*.json` 为准，不替代上述 v2.14.1 成品的历史验收记录。
