# Debug 系统开发规范与控制台使用

适用基线：本体 **2.1.1**、存档结构 **9**。控制台始终可用，外部 Agent 接口仍按 Debug 配置开放。发布包与源码共用下面的隔离与调用契约。

### 诸天调试工作台

控制台内展开“诸天调试 · 状态与行动”，先创建调试副本，再“读取诸天”。目标选择覆盖十一界地方事务、新增异象与战地案、四界联系、已知战局与进行中的个人任务；公开投影仍按副本角色的界层和亲历记录筛选，调试高界内容可先在副本中调整所在界面。选择行动后显示可用性及受限原因；“预览行动”检查投入，“在副本执行”沿正式规则推进。高级参数折叠在“行动参数”内；切换目标、恢复快照或修改副本后必须重新预览。

- `heavens inspect [target_id]`：在一次性临时引擎中读取公开投影，并附独立副本的诸天原始状态。属于 `preview`，不写回整理、RNG、年度或成就。原始状态只出现在调试接口，不进入普通诸天页面。
- `heavens act <action> <options> [target_id]`：自动获取本次行动的正式序号与诸天修订号，先核价再执行。地点、修为、工时、灵石、托管、事件暂停照常生效；失败沿现有调试事务回滚。它不生成战争人物、不直接完成任务、不传送角色。
- 原有 `heavens view`、`heavens preview`、`heavens command` 保留，适合分别检查投影、报价和精确回执。

例如在独立副本中执行：

```text
debug start
heavens inspect
heavens inspect human_beacon
heavens preview incident_survey '{}' human_beacon
snapshot create before_heavens
heavens act incident_survey '{}' human_beacon
snapshot restore before_heavens
heavens act configure '{"watch":false}'
```

人物须实际位于无棣原并满足本案条件。Agent 通过同一 Registry 自动发现 `cultivation_heavens_inspect`、`cultivation_heavens_act` 工具；结构化写入必须带当前独立会话 `expected_revision` 和唯一 `request_key`。不确定是否成功时沿原参数与同一个键重试，避免再次推进年份。控制台工作台也使用该回执契约。

## 1. 优先遵循的开发范式

Debug 是应用边界装配的开发工具。正式玩法不得为了控制台新增条件分支、模型字段、随机数抽取或模块依赖。新增玩法与调试功能共同遵循以下约定：

1. **先确定权威状态与转换契约。** 找到数据真实来源，列清必须一起更新的字段。NPC 的生死、拘禁、名册不能用单一开关代替；灵石来源是背包 `spirit_stone`，不是新增一个计数器。
2. **正式系统保持单向依赖。** `server → debug → engine / rules / models`；正式引擎、系统、模型和规则不得反向导入 `debug`。`tools/check_module_dependencies.py` 会拒绝这类反向依赖。不增加 Mixin，不进行全局 monkey patch。
3. **先登记命令，再接界面。** 命令名称、参数类型、范围、枚举、类别、帮助和 JSON Schema 只有 Registry 一份来源。控制台、结构化 HTTP、CLI 和 MCP 从同一注册表发现能力。新增命令不能新增 HTTP 分支或另写前端解析器。所有执行调用 `POST /api/debug/command`。
4. **只读查询从独立文档取值。** 不调用引擎 `_load`、`get_game`、自动补全、迁移写回或 RNG。当前普通游戏 GET 可能准备并写回状态，不能当成纯查询服务。
5. **修改在脱离权威状态的副本上完成。** 先保存执行前状态，执行、校验，再原子提交。多字段修改一旦失败，游戏、RNG、概率覆盖和成就都不提交。输入错误用 `CommandError`；程序错误保留堆栈并返回内部错误，不能伪装成输入错误。
6. **模拟调用正式规则。** 不复制一套年度、战斗、突破算法。`action advance`、`event choose` 与界面共用 `Runtime.staged` 存储边界；执行正式操作的三组权限守卫，并使用 `request_scope`。新增模拟必须接入具名能力、事务和差异检查，不能直接写原存档，也不能把任意引擎方法名交给调用者。
7. **覆盖只放在调试会话中。** 当前唯一规则覆盖是普通修为突破概率，由 `engine_adapter.SessionEngine` 的单实例适配完成。正式 `GameEngine` 与玩家存档均不新增 Debug 字段。不能因开发需求修改全球规则常量。
8. **命令与自然变量同义同名。** 玩家字段使用 `realm_index`、`layer`、`opportunity`；物品使用真实 ID `spirit_stone`。邻域未来命令必须使用 `voisinage`，禁止 `linyu`、`neighborhood` 等拼音或近义别名。英文空格表达动作：`player set ...`、`snapshot restore ...`；不支持自然语言猜测或模糊纠错。
9. **展示投影不得冒充玩家字段。** `spirit_stones` 是已有灵石总量语义的显式操作，映射到背包条目；`breakthrough_chance` 是已有概率计算语义的会话覆盖。新增类似字段必须说明其真实归属、作用范围与撤销方式。
10. **按行为验证。** 至少验证正常模式不变、查询纯度、失败回滚、原角色和成就隔离、同一场景正常/调试无覆盖时结果一致、非法参数、重复/并发执行。复杂转换还需验证死亡、跨界、待处理事件和读档。

正式系统未来新增数据库、文件或其他持久化副作用时，先提供可替换的存储能力，再明确如何进入 Debug 事务和快照。首版事务明确覆盖角色存档与全局成就，不会自动捕获任意新文件；未适配的新副作用不能直接开放给调试会话。

不支持 `eval`、`exec`、Python REPL、任意属性写入和任意文件路径命令。`state get` 仅能读取会话游戏文档中的 JSON Pointer，不能访问 Python 对象、文件或修改字段。DLC 的未来调试注册应在 Debug 装配边界按已加载内容注册，不让 DLC 玩法加载过程依赖 Debug。当前未开放第三方可执行注册脚本。

## 2. 代码职责与扩展流程

| 文件 | 职责 |
| --- | --- |
| `cultivation_life/debug/registry.py` | 固定语法、类型元数据、注册、纯查询标记、帮助与补全 |
| `cultivation_life/debug/commands.py` | 首版命令、字段白名单、资源映射、快照操作 |
| `cultivation_life/debug/capabilities.py` | 本体通用操作白名单、具名引擎调用与复杂参数 Schema |
| `cultivation_life/debug/schema.py` | 布尔值、可选参数、数组和对象的严格校验，与工具发现使用同一 Schema |
| `cultivation_life/debug/state.py` | 纯查询、轻量校验、摘要、带上限的状态差异 |
| `cultivation_life/debug/runtime.py` | 会话、原子提交、执行前现场、操作记录、复现包 |
| `cultivation_life/debug/engine_adapter.py` | 唯一引擎适配位置；普通修为概率覆盖 |
| `cultivation_life/debug/gateway.py` | HTTP 与隔离引擎的装配；拒绝逃逸到正式角色的操作 |
| `cultivation_life/debug/client.py` | 标准库客户端、实时工具发现；只访问本机 Debug HTTP 入口 |
| `cultivation_life/debug/agent.py`、`scripts/debug_agent.py` | CLI、MCP stdio 协议与可从任意工作目录启动的入口 |
| `web/debug-console.js`、`.css` | 控制台、会话标识、命令历史、元数据补全 |

新增一个查询或简单修改命令的流程：

1. 确认真实字段、单位、范围和权威来源；复杂玩法先明确系统契约。
2. 在所属命令模块定义处理函数，接收 `Context` 和显式参数。禁止把完整引擎传给所有处理函数。
3. 登记 `Command(name, kind, description, handler, arguments, requires_session)`；通过 `Argument` 声明 string/integer/number/boolean/object/array、枚举、范围及可选参数。名称重复立即报错；补全、帮助和工具 JSON Schema 自动生成。参数必须使用真实语义名称；结构化输入严格拒绝未知键、数值字符串、布尔数值及非有限数。嵌套对象也必须声明字段，不开放任意载荷。
4. 在 `tests/test_debug_console.py` 或对应专题测试中验证语义和隔离。新 Query 必须加入查询纯度覆盖；新规则适配必须验证真实消费入口。
5. 同步本文示例；完整可执行命令以运行时 `help` 为准。

支持的类别为 `query`、`mutation`、`session`、`snapshot`、`export`、`simulation`、`preview`。`query` 只读保存文档；`preview` 可调用正式预览，但其读档整理、RNG 和成就副作用全部留在临时存储并丢弃，成功失败均不改会话。`game view` 则明确属于 `simulation`，像界面一样提交状态整理以提供后续可操作的实际 ID。会话和快照管理不属于游戏玩法推进。Agent 客户端不能导入引擎或读取存档；新增能力必须在服务端注册，不能让 AI 临时编写内部状态修改脚本。

## 3. 开启和关闭

### PC 源码运行

使用 `python launcher.py` 或 `python -m cultivation_life.server` 启动。控制台始终可用，不再读取 `Debug` 配置来决定是否开放。在角色页面按键盘左上角 **~ / `（Backquote）** 切换；无需 Ctrl。普通文本框输入时不拦截此键。旧 EXE 需要重新构建才包含新入口。

### Android

在游戏设置中点击“开发者控制台”。无需修改配置、重启或使用实体键盘。原生桥也可直接打开同一控制台；正式 APK 仍不开放 WebView 远程调试。

复现包通过系统文件选择器导入、导出，不扩大存储权限。“断开会话”只断开当前页面，保留调试副本；关闭控制台仍停留在副本。改变旧 `Debug` 配置既不会禁止控制台，也不会把已有会话路由到正式存档。无效会话继续拒绝访问，原生存档传输与同源认证保持原有隔离。

## 4. 基本操作

选择并进入一个角色，PC 按 **~ / `**，Android 在设置中点击“开发者控制台”。正常游玩不显示调试横条，进入副本后持续显示标识。然后执行：

```text
debug start
player fields
player set spirit_stones 100000
give spirit_stone 5000
remove spirit_stone 1000
realm list
player set realm_index 4
player set layer 7
player set opportunity 100000
player set breakthrough_chance 0.8
snapshot create before_test
```

`debug start` 在 `data/debug/` 建立独立副本，角色 ID 保持不变，通过随机会话 ID 和独立存储区区分。顶部持续显示 **DEBUG · 独立副本**。关闭控制台后可用正常游戏按钮修炼、交互和战斗，操作与成就都只提交到副本。另一个没有会话的标签页继续使用原角色。

按 Enter 执行；上下方向键查看最近 100 条命令；Tab 使用注册表补全命令和枚举参数；Ctrl+L 清空屏幕输出。命令按大小写精确匹配。文本命令上限 32,768 字符，字符串参数通常不超过 2,048 字符。文本参数支持引号，不支持 Shell 运算符、管道或复合脚本。布尔参数使用 `true` / `false`；数组、对象使用单引号包裹 JSON；末尾可选参数可省略，中间可选参数用 `null` 占位。结构化 API 使用原生 JSON 类型，无需再给对象套字符串。

```text
debug status
debug sessions
debug stop
debug resume <session_id>
```

`debug stop` 返回原角色，副本保留；`debug resume` 可恢复已有副本。`session_id` 取自 `debug sessions`，不是角色 ID。会话保存在磁盘；浏览器连接标识只保存在当前标签页的 sessionStorage。

Debug 关闭、会话丢失、配置变化或服务错误时，不自动回退到正式存档。用“断开会话”显式返回。调试过程中创建/删除角色、普通存档码导入导出及修改扩展启用状态会被拒绝；切换角色前先退出调试。

## 5. 玩家数据与概率的准确含义

| 命令字段 | 类型与范围 | 含义 |
| --- | --- | --- |
| `spirit_stones` | 整数，0–10^15 | 背包 `spirit_stone` 的总量；不在 Player 中增加字段 |
| `opportunity` | 有限数，0–10^15 | 当前机缘；后续正常操作仍遵循本境界的规则 |
| `realm_index` | `realm list` 中的索引 | 设置境界，层数重置为 1，清除等待突破/飞升等标志；不自动跨界或发放晋升奖励 |
| `layer` | 当前境界合法层数 | 设置该境界层数；遵守配置中的当前世界修为上限 |
| `breakthrough_chance` | 有限数，0–1 | 独立会话中的普通修为大/小境界成功概率覆盖 |
| `age` | 整数，0–10^9 | 直接修改年龄，不推进世界，也不结算历年收益 |
| `lifespan` | 整数，1–10^9 | 修改寿元，不自动解除死亡状态 |
| `hp`、`mp` | 有限数，0–10^15 | 原始资源值；后续正式准备/结算仍可能按资源上限修正 |
| `heart_demon` | 有限数，0–10^9 | 当前心魔 |
| `karma` | 有限数，−10^9–10^9 | 当前因果 |
| `sha_qi` | 整数，0–10^9 | 当前煞气 |

境界/层数设置在待处理事件或试炼期间拒绝执行。境界变更后执行正常界面排斥：人界未压制的化神后期进入对应二级界面，零级／二级界面的九阶进入对应三级界面；不世秘境没有界面上限。也可从相应快速开局创建源角色。设置境界不是一次自然突破，不增加寿元或保证门槛已满足。

概率覆盖修改 `_breakthrough_chance` 的最终概率，保留原来的随机数抽取和其他结算。它不绕过机缘、丹药、世界、道途和待处理事件的门槛，**也不覆盖炼体、仙界/修罗专属养成、劫战或 NPC 突破**。因此设为 1 不代表任何“突破”按钮都必定完成全部流程。

```text
player get breakthrough_chance
player set breakthrough_chance 1
player set breakthrough_chance 0
player reset breakthrough_chance
```

0 表示对应概率检定失败，1 表示成功；重置后恢复正常计算。覆盖随会话与快照保存，不写入玩家存档或正式规则配置。

## 6. 查询、快照和复现命令

```text
help
help player
help snapshot restore
version
player
player get realm_index
player get spirit_stones
player fields
realm list
npc list
npc inspect <npc_id>
rng state
rng seed 114514
save validate
extensions
```

`npc list` 最多显示 200 条来源记录；`npc inspect` 显示对应 ID 的所有已记录来源，包括世界、宗门、家族、关系和受控人物表。它不复活、迁移或重新绑定人物，也不把重复来源一律判定为错误。

`rng state` 不抽随机数；`rng seed` 只重置副本未来的 RNG，不会重新生成已有世界。`save validate` 仅验证模型解码、境界/层数、世界、基础数字与 RNG；它不是全部 DLC 业务不变量的完整证明。

```text
snapshot create before_test
snapshot list
snapshot diff before_test
snapshot restore before_test
snapshot restore initial
snapshot restore last_before
snapshot delete before_test
repro export
```

命名快照最多 8 个，名称使用英文字母开头的 1–48 位字母、数字、`_` 或 `-`。`initial` 为建会话时的状态；`last_before` 为最近一次被记录操作之前的状态；两者保留，不允许覆盖或删除。快照包含玩家与世界完整数据、RNG、会话覆盖和独立成就。

差异输出最多显示 100 个变化位置；大型集合使用摘要和预览，完整状态仍在快照。日志最多保留最近 100 条；控制台屏幕输出也有上限，不代表复现包丢失完整当前状态。

## 7. 故障复现工作流

1. 开启 Debug，在角色中执行 `debug start`。
2. 配置测试状态，执行 `snapshot create before_test`。
3. 关闭控制台，使用正常界面触发问题；或执行要测试的控制台命令。
4. 出错后立即 `repro export`，下载 JSON；安卓使用“保存复现包到文件”。不要先进行无关操作，以免替换最近的执行前检查点。
5. 在另一环境开启 Debug，使用“导入复现包”。PC 也可粘贴剪贴板 JSON。该操作通过注册命令 `repro import` 接收文件内容，**不接受任意文件系统路径**。
6. 导入生成新会话。检查版本、代码和内容指纹差异，执行 `snapshot restore last_before` 或恢复命名快照，再按记录中的操作手动重试。

复现包含初始状态、当前状态、最近执行前状态、命名快照、临时概率覆盖、独立成就、最近操作的名称/参数、前后摘要、失败堆栈、请求编号、版本、Python 平台、扩展清单、界面偏好和内容指纹。Android 还纳入随包构建来源记录的哈希，避免将虚拟 Python 目录误当成可遍历源码。它包含完整角色信息，应只交给实际需要诊断的人。主题偏好属于应用共享设置；导入复现包不会自动改动目标设备的主题。

首版不自动重放命令序列、不固定运行时时钟和 UUID、不追踪每一次随机数调用。因此保证的是**保留现场并支持隔离重试**，不是跨版本、跨平台逐字节确定性回放。包格式为 `CultivationLife.debug.v1`，会话和导入请求上限均为 64 MiB；快照过多触及上限时应删除旧命名快照或建立新会话。

## 8. 测试与发布边界

```powershell
python -m pytest tests/test_debug_console.py tests/test_debug_agent.py tests/test_audit_regressions.py tests/test_runtime_config.py -q
python tests/browser_debug_console.py
python tools/check_module_dependencies.py
python tools/check_documentation.py
```

Android 的 `debug-console` instrumentation 阶段验证原生 WebView 控制台、四主题、正常操作写入副本、原角色隔离、原生返回和不依赖配置的副本隔离。APK 编译和 Lint 不能替代这些行为检查。正式包必须继续保持默认 `Debug=False` 及原有发布验收，不得将开发测试 APK 当成新正式发行。

当前暂未实现：NPC 生命周期修改、强制跨界、任意事件触发、跳过结算的时间设置、RNG trace、批量战斗/概率模拟、自动回放和第三方 DLC 可执行调试插件。`action advance` 已支持正式行动推进，不提供跳年或跳过事件的捷径。这些功能在明确状态转换契约和验证范围后逐项扩展，不通过任意字段写入绕过。

## 9. Agent 工具与结构化调用

这一层由项目维护，AI 只负责发现并调用工具，不需要生成存档修改程序。服务进程仍是唯一玩法执行者。客户端使用 Python 标准库，不依赖模型 SDK；它不会加载游戏内容或引擎，也不会自行开启 Debug。

### 9.1 启动与工具发现

先开启 Debug 并启动游戏服务。默认地址为 `http://127.0.0.1:8000`；若启动器实际使用其他端口，以实际地址替换。工具只接受本机 HTTP origin，不接受远程主机、路径、凭证、代理或跳转。退出游戏或关闭 Debug 后工具不能继续执行，更不会回退到正式角色。

```powershell
python scripts/debug_agent.py tools
python scripts/debug_agent.py call "save list"
python scripts/debug_agent.py call "debug start" --game-id <game_id>
python scripts/debug_agent.py call "debug status" --session-id <session_id>
python scripts/debug_agent.py call "action list"
```

`tools` 输出当前服务的工具名与 JSON Schema。可在项目根目录使用等价入口 `python -m cultivation_life.debug.agent`；独立脚本支持任意工作目录。CLI 成功输出 UTF-8 JSON 并返回 0，失败写 stderr 并返回 1，不自动重试。

支持 stdio MCP 的 Agent 可注册以下服务器（按实际 Python 和项目位置调整）：

```json
{
  "mcpServers": {
    "cultivation-life-debug": {
      "command": "G:\\Anaconda3\\python.exe",
      "args": [
        "F:\\CultivationLife\\scripts\\debug_agent.py",
        "--url", "http://127.0.0.1:8000",
        "mcp"
      ]
    }
  }
}
```

MCP 桥固定支持 **2025-11-25 / 2025-06-18** 的 initialize 握手与 stdio tools 子集，不声称支持后续协议版本。实现 `initialize`、初始化通知、`ping`、`tools/list`、`tools/call`；不提供资源、提示模板、订阅、HTTP MCP 或后台任务。每行一条 UTF-8 JSON-RPC，stdout 只输出协议消息。规范依据：[stdio 传输](https://modelcontextprotocol.io/specification/2025-11-25/basic/transports)、[生命周期](https://modelcontextprotocol.io/specification/2025-11-25/basic/lifecycle)、[Tools](https://modelcontextprotocol.io/specification/2025-11-25/server/tools)。

工具名称使用 `cultivation_` 前缀及命令名的下划线形式，例如 `cultivation_player_set`、`cultivation_action_advance`。完整工具清单实时取自服务端；命令内部的字段和内容 ID 不翻译、不增加近义别名。`tools/list` 不需要提前选角色；涉及会话的工具显式要求 `session_id`，不维护 Agent 隐式当前角色。

### 9.2 推荐调用顺序

1. `cultivation_save_list` → 从只读结果取得 `game_id`。
2. `cultivation_debug_start` → 以该 `game_id` 建立独立副本，保存返回的 `session_id`。
3. `cultivation_state_summary` / `cultivation_debug_status` → 检查场景与 `revision`。
4. `cultivation_snapshot_create` → 保存命名基线。
5. 使用数据或模拟工具；需要写入时传最新 `expected_revision` 和新的 `request_key`。
6. 查询差异、检查事件及日志。失败后导出 `cultivation_repro_export`，或从命名快照恢复再试。

MCP 的一次写入参数示例（假设当前 revision 为 0）：

```json
{
  "name": "cultivation_player_set",
  "arguments": {
    "session_id": "由 debug start 返回的 32 位会话 ID",
    "expected_revision": 0,
    "request_key": "prepare_stones_001",
    "arguments": {"field": "spirit_stones", "value": 100000}
  }
}
```

这里外层 `arguments` 是 MCP 参数；内层 `arguments` 是注册命令参数。命令查询可使用 `{"arguments": {}, "session_id": "..."}`；无会话查询只需要 `{"arguments": {}}`。MCP 返回 `structuredContent` 和兼容文本内容；执行错误设置 `isError=true`。复现导入通过 `bundle` 对象传完整 JSON，不把服务端文件路径交给 Agent。

无需 MCP 的自动化程序可直接复用内置客户端：

```python
from cultivation_life.debug.client import DebugClient

client = DebugClient("http://127.0.0.1:8000")
sources = client.call("save list")["data"]
session = client.call("debug start", game_id=sources[0]["game_id"])["data"]
sid = session["session_id"]
status = client.call("debug status", session_id=sid)
result = client.call(
    "player set", {"field": "breakthrough_chance", "value": 1},
    session_id=sid, expected_revision=status["revision"], request_key="chance_001",
)
print(result["data"], result["revision"])
```

### 9.3 HTTP、并发与重试契约

仍使用 `POST /api/debug/command`。旧控制台的 `command` 文本保持兼容；当存在 `arguments` 对象时，`command` 必须为精确注册名称，参数按 Schema 类型提供。顶层允许 `command`、`arguments`、`game_id`、`session_id`、`bundle`、`expected_revision`、`request_key`，未知键拒绝。接口不接受任意方法名、Shell 命令或任意属性写入。

```json
{
  "command": "action advance",
  "arguments": {"action": "rest", "units": 1},
  "session_id": "由 debug start 返回的 32 位会话 ID",
  "expected_revision": 3,
  "request_key": "rest_001"
}
```

- `mutation`、`snapshot`、`simulation` 的结构化调用必须带版本和请求键；只读查询不要求这两项。文本控制台仍按串行事务执行。
- `revision` 是单调递增的会话执行版本，包含命令、界面操作与失败记录，不是存档结构版本。纯查询不增加版本；界面 GET 如果准备并改变副本，也会增加版本。新会话或导入新会话从 0 开始。
- 成功写入和回执在同一 JSON 原子提交；相同会话中同一 `request_key`、命令、参数及预期版本重试，返回首次结果和 `replayed=true`，不再次执行。回执保留最近 64 个；过期请求仍会因旧版本冲突而拒绝，不会重复扣费。返回的 revision 属于首次执行结果，重放后应重新读取当前状态。
- 请求键只用于上述三类写入，必须为 1–64 位字母、数字、`_` 或 `-`。使用同一键执行不同内容会报错。版本冲突返回输入错误；先查询当前状态，确认意图，再使用新键及新版本发起新操作。
- `debug start`、`scenario create`、`repro import` 属于会话创建，不支持去重键；它们可能重复创建隔离副本，不修改源存档。不对未知结果的会话创建盲目重试，先检查 `debug sessions`。
- 已进入命令处理函数的失败不提交游戏/RNG/成就变化，但保留失败现场、结构化参数和请求键，并推进执行版本；此时先读取日志和状态。语法、参数类型、去重键与版本校验在执行前拒绝，不写日志或增加版本。不将内部 `ValueError` 直接当作可忽略的输入错误。超时不等于操作未提交：客户端不自动重试写入，调用者只能用原键和原参数查询重试结果。
- 快照恢复只恢复游戏、覆盖与成就，不倒退版本、日志和去重回执；导入复现包生成新会话并重置版本/回执，不信任包中附带的传输状态。

## 10. 通用调试与 Agent 指令

以下命令在游戏控制台、结构化 HTTP、CLI 和 MCP 共用实现。英文名称及变量 ID 精确匹配：

| 指令 | 用途与限制 |
| --- | --- |
| `save list` | 发现源存档 ID，不调用正式读档补全、不写回 |
| `state summary` | 玩家场景、事件/试炼阻塞项及当前状态指纹 |
| `state get /player/realm_index` | 只读 JSON Pointer；数组使用 `/player/inventory/0`，不支持属性执行 |
| `inventory` | 查看副本完整背包 |
| `item list "" 0` | 按真实 ID/显示名子串检索；空查询查看全部，offset 从 0 起，每页 50 项 |
| `item give spirit_stone 10` | 使用正式 `add_item`；数量整数 1–10^9，总量不超过 10^15 |
| `item remove spirit_stone 10` | 使用正式 `remove_item`；数量不足整体拒绝 |
| `npc find "" 0` | 按 ID/显示名子串检索来源记录，每页 50 条，返回 next_offset |
| `action list` | 发现真实行动 ID 和配置，不承诺当前角色都可执行 |
| `action advance rest 1` | 正式规则推进 1–10 个行动单位；单位对应年份按境界决定，事件可中断 |
| `event inspect` | 查看已保存待处理事件及 choice_id；enabled 为保存时状态，执行时重新检查 |
| `event choose <choice_id>` | 正式事件选择；遵守条件、消费、随机与后续事件，不强制成功 |
| `journal list` | 查看最近 100 条记录、请求编号、状态差异与失败堆栈 |

物品命令只用于普通背包条目；`immortal_trace` 在正式规则中映射到独立养成资源，当前明确拒绝，避免与背包数量混用。不会通过新增通用属性写入去绕开专属养成契约。

```text
snapshot create before_action
state summary
item list "pill" 0
inventory
action list
action advance rest 1
event inspect
journal list
snapshot diff before_action
```

有待处理事件时先查看 `event inspect` 并按其真实 ID 执行 `event choose`。不存在的选项直接拒绝；其他玩法门槛仍由正式规则判断，出错整体回滚并保留日志。没有自动循环刷行动、自动选择事件、强制跨界或复活操作；遇到试炼等当前未开放工具的流程，可以在同一调试副本的游戏界面继续操作。

## 11. 本体与 DLC 操作覆盖

当前注册 **180 个命令/工具**，通过固定白名单覆盖 **137 个现有角色操作入口**，包含本体通用功能及全部当前 DLC 角色操作入口。普通操作直接调用正式引擎方法，保持三组守卫、消费、关系转换、跨界和时间结算，不做 HTTP 转发或任意方法反射。完整映射见 [角色入口清单](debug-base-coverage.md)；新增 17 条专属/旧调试入口的示例见 [DLC 指令清单](debug-dlc-coverage.md)。其中两条显式标记的调试捷径跳过普通获取条件，仅作用于副本。这表示可通过工具执行这些入口，不表示所有 DLC、分支组合或游戏状态已经穷举测试。

### 从空白开始复现

无需先创建一个正式角色：

```text
scenario list
scenario create "Repro Test" supreme_metal dao 42 core
snapshot create baseline
game view
game view /market
game view /map
game view /player/known_techniques
game view /crafting_system
```

`scenario list` 返回真实灵根、道途、开局世界及快速开局配置。预设会按正式建角规则覆盖对应角色参数；没有 DLC 或未解锁预设时仍按正式规则拒绝。`scenario create` 在临时引擎建立角色，再保存为 Debug 会话，正式角色目录不会出现新角色或成就文件。退出此类会话返回标题页；导出再导入仍保留这一行为。旧 `debug start` 复制原角色的流程保持不变。

`game view` 不带路径时返回面板名；带路径时返回与界面同源的数据，包含市场货架、地图目的地、已学功法、制作材料实例、组织、外交等可操作 ID。其读取准备可能生成货架、整理 NPC、结算读档状态并消耗 RNG，因此提交到副本、记录版本和执行前快照。Agent 必须带 `expected_revision`、`request_key`。成功返回的 ID 来自已提交的副本；后续操作仍需遵守事件中断或状态变化后的新门槛。纯查询继续使用 `state get`，不把原始文档和展示字段混用。

### 通用操作示例

```text
player set spirit_stones 1000000
item give healing_pill 2
item use healing_pill
market buy <offer_id>
market lock <offer_id>
technique equip <technique_id> main
breakthrough attempt
body breakthrough
sense breakthrough
map travel <destination>
teleport action <action> <destination>
npc contact <npc_id> improve
party <npc_id> invite
setting set manual_combat_plan true
combat plan guard 10 never 0.4 false true
spirit field reclaim
formation preview '[null,null,null]'
formation save '["material-id",null,null]' "Test Array"
alchemy refine healing_pill '[{"item_id":"harvested-herb-id","quantity":1}]'
upper voisinage train <voisinage_id>
snapshot diff baseline
```

这些示例展示调用方式，`<...>` 须替换为本会话真实 ID；突破、传送、组队、生产和上界邻域均需要满足原有资格，示例不保证当前角色即可执行。`formation preview`、`crafting preview`、`merchant preview`、`puppet preview`、`tianji preview`、`custom lineage prepare` 不提交临时状态，不需要写入版本或去重键，也不触发界面随后的游戏刷新。预览结果不是绕过条件的许可；实际制作仍重新检查库存与规则。

### Agent 调用示例

例如已经取得会话及最新 revision 后，调整战斗预案：

```json
{
  "name": "cultivation_combat_plan",
  "arguments": {
    "session_id": "替换为真实会话 ID",
    "expected_revision": 8,
    "request_key": "combat_plan_001",
    "arguments": {
      "stance": "guard",
      "mp_reserve": 0.4,
      "transformations": false
    }
  }
}
```

省略的可选字段保留正式入口默认行为；不会把未提供的配置字段强制写成默认值。可通过 `help <命令组>`、`capability list` 和 MCP `tools/list` 获取准确参数。`voisinage` 保留真实拼写，既不解析拼音，也不替换为 `neighborhood`。材料清单中的 `item_id`、交换材料的 `id`、阵法材料实例 ID 各自沿用正式接口含义。

### 维护与验证

- 新增角色 POST 入口时，同步 `capabilities.py`，或在 `EXCLUDED_OPERATIONS` 写明专属玩法/不可开放的理由。`test_all_game_post_routes_are_explicitly_classified` 会拒绝遗漏的入口，不能靠添加任意操作转发接口完成覆盖。
- 新增已有入口的子操作、字段或复杂结构时，同步其 `Argument` 和嵌套 Schema，并增加真实调用测试。入口清单测试不能自动证明所有子分支的参数都正确。
- DLC 命令声明内容要求并复用正式可用性判定；禁用时拒绝执行，工具不切换内容包。调试捷径必须显式标记，不能在帮助中冒充普通规则。
- `preview` 不得提交临时状态；需要准备后可操作 ID 的读取使用 `game view`。修改日志、版本或去重状态的逻辑继续统一放在 Runtime，玩法模块不反向引用 Debug。
- 当前专项验证包含入口分类、137 个具名引擎调用的签名与参数类型、字符串/布尔/数组/对象及可选参数、真实制作和互动流程、规则拒绝与回滚、不依赖 Debug 配置且拒绝无效会话，以及没有任何 DLC 目录的纯本体子进程。

发布验收使用当前版本对应的回归、浏览器、二进制和设备检查；发布结果以 `dist/` 内当前发行清单为准。
