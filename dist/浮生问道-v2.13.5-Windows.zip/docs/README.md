# 项目文档索引

维护基线：**本体 v2.13.4 / 存档结构 10**。旧结构 1–9 不兼容，不做等级映射，须新建角色。

文档文件名中的历史版本编号用于稳定链接，当前规则看正文。数值校准保留必要的采样条件；更新日志只记录当前发行说明。资料中涉及“旧档”的补全仅适用于允许载入的结构。

## 项目与开发

- [十一界独立地图素材与自由相机](maps-2132.md)：独立 SVG、鼠标跟随、自由轨迹球与专项发行。
- [立体地图与道路拓扑](maps-2131.md)：多中心环路、边陲小环、十一界地貌、可选坐标与专项发行。

- [地方影响力与组织迁址](territory-development.md)：连续扩张、地区政策、真实府库与资材、地区战争及同界迁址。

- [万灵争衡：百族兴衰](monster-civilizations-development.md)：独立生态、氏族、王庭、可视化与性能边界。

- [势力传承、外姓承宗与当地建阵](organizations-290.md)：本体功能、权限、真实收支、绝嗣口径和长时间推进验收。

- [战争军需与组织府库](war-logistics.md)：商品消耗、真实采购、府库审批与开发验收边界。
- [分类导航与性能复核](navigation-performance-280.md)：固定分类、灵域传承入口、延后绘制、性能采样与继续优化边界。
- [经济 V2](economy-v2.md)：本地市场、增长、货架预留、真实商队经营、资金去向和后续组织边界。
- [年度收支与经济托管](economy-trust-and-income.md)：成交额与收入区分、护卫委派、自动经营、盈利投资及性能边界。
- [产业经济审计](economy-estate-audit.md)：缺料与市场流水归属、固定设施维护、停产与委托权限、自动利润及欠费成本。
- [经济消费端重平衡](economy-rebalance-260.md)：六项数值规则、真实消耗、参战境界后勤、经营止损和百年性能验收。
- [商品、产业与境界需求细化](economy-diversity-260.md)：每界九材料、有限原料链、境界需求、延寿上限与猎场产权。
- [势力收支与本地市场检索](organization-balance-and-market.md)：境界维护、盈余养护、三年储备、坊市双入口与正则搜索。
- [商品供给审计](economy-supply-catalog.md)：权威商品目录的用途、品阶、供给来源与实物投入表。
- [三级界面成就](upper-achievements-270.md)：境界、邻域、实际机构身份与 DLC 专属修持的判定和验收。

| 文档 | 用途 |
| --- | --- |
| [项目入口](../README.md) | 当前版本、玩法、启动、测试与构建 |
| [完整诊断](project-diagnosis.md) | 当前架构状态、验证方法及开发边界 |
| [产品与系统规格](修仙人生模拟游戏_GDD_V1.0.md) | 已实现系统、世界、时间、数据归属 |
| [引擎架构](../cultivation_life/engine/README.md) | 显式依赖、关系、时间与读档阶段 |
| [Debug 开发规范与控制台](debug-development.md) | 开发范式、隔离会话、CLI/MCP Agent 工具、指令、快照与复现包 |
| [Debug 本体覆盖清单](debug-base-coverage.md) | 通用功能操作链、全部 137 个角色入口映射与验证范围 |
| [Debug DLC 指令清单](debug-dlc-coverage.md) | 剩余 17 个入口、内容门禁、立祖预览、结构化参数与使用示例 |
| [系统边界](../cultivation_life/system/README.md) | 各算法目录、兼容入口与反向依赖约束 |
| [Android](../android/README.md) | 构建、签名、设备和发布证明 |
| [主题维护](../web/themes/README.md) | 四主题与共享控件 |
| [扩展包](../dlc/README.md)、[MOD](../mods/README.md) | 清单、合并与启停 |
| [更新日志](../CHANGELOG.md) | 当前发行说明与兼容信息 |

## 规则与专题

- [人物生存、拘禁与名册契约](npc-custody.md)
- [存档码格式与结构迁移](save-code-format.md)
- [诸天实装进度：十一界事务、四界往来与局部战争](heavens-implementation.md)
- [空间裂缝、符箓与界面排斥](spatial-talismans.md)
- [统一跨界流程](world-transitions.md)
- [战斗内核与资源](combat-domains.md)
- [邻域效果与主战资格](combat-effects.md)
- [战斗语义 V3](combat-semantics.md)
- [本体种子随机异闻](generated-events.md)：情境生成、真实选择结算、存档与后续副本复用。
- [万象试境 DLC 实现](trial-sites.md)：十一界 7／14／22 层、独立 DLC 开关、可视化试境与快捷入口、零时间状态及真实守关领奖。
- [仙界道统与养成](doctrines.md)
- [仙窍、灵域与交通](immortal-1470.md)
- [压制与战斗预案](immortal-1471.md)
- [仙境劫战](immortal-1490.md)
- [金光、瑶池与凭证](immortal-1510.md)
- [仙脉费用与校准方法](immortal-vein-balance.md)
- [合练与三尸规则](three-corpses-1512.md)
- [剧情战斗校准方法（含剧透）](luo-spirit-calibration.md)
- [仙界修行、选举与经验](experience-1520.md)
- [机构归属](institutions-1513.md)
- [瑶池经济、议政与人物交往](yaochi-governance-1511.md)
- [三界上境及 DLC 分流](upper-worlds-1500.md)
- [三界本体邻域与机构](upper-voisinages-1522.md)
- [修罗王庭](asura-court-1530.md)
- [教程入口](tutorial-1480.md)
- [操作引导](tutorial-1481.md)
- [百科维护](handbook-1481.md)
- [十一界归墟现行规格](归墟之潮_九死一生_DLC策划案_V0.2.md)

- [万妖归宗本相铸域与开局适配](monster-true-forms.md)

## 待实现策划

- [万象试境副本策划案 V0.1](万象试境_副本策划案_V0.1.md)：本体种子探索、五事件守关、三级界面 7／14／22 层、零时间静态副本与地图概略图标；已确认约束及待讨论参数分别标明。

- [诸天系统策划案](诸天系统与跨界战争_策划案_V0.1.md)：当前 V0.5 开工基线，保留宇宙整体与有限认知定位，确定首轮顺序、境界参与初值、法则天海分支成本、最小数据与接口、年度中断、短活动结算、事务恢复及分阶段验收；M0、M1 及 M2 的四界求证、和平协作、镜律场域与因果遗址已落地，人界低阶征兆及当地对照已开放，四界个人访学往返已开放，现有合作 NPC 的回访与实际返乡已开放，四界同道单件阵材的真实运输与交货已开放，四界真实居民的有限接引与长期迁居已开放，自主人口迁徙、通用商贸货运与跨界战争尚未开放，文件名保留以维持链接。

## 维护约定

数值依据优先读取 JSON 配置和规则实现，存档结构依据 `save_schema.py`，本体版本依据 `version.py`，扩展版本依据各自清单。修改当前行为时同步相关专题及百科；不要把历史版本号统一替换成当前版本。新专题需进入本索引。

运行 `python tools/check_documentation.py` 检查本地 Markdown 链接、索引覆盖及关键版本声明。该工具不联网验证外部链接，不保证自然语言规则全部正确；新数值与迁移约定仍需人工核对代码。

- [跨界开发规范](world-transition-development.md)
- [v2.1.1 跨界全量审计](world-transition-audit.md)
- [逐字段归属合同](world-transition-state-contract.json)

- [照魂归真与妖鬼突破劫](soul-forms-and-upper-trials.md)

- [地图中心平移与触屏手势（v2.13.3）](maps-2133.md)
